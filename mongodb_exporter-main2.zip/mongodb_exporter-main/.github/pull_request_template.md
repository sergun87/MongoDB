[PMM-XXXX](https://jira.percona.com/browse/PMM-XXXX) (optional, if ticket reported)

- [ ] Links to other linked pull requests (optional).

---

- [ ] Tests passed.
- [ ] Fix conflicts with target branch.
- [ ] Update jira ticket description if needed.
- [ ] Attach screenshots/console output to confirm new behavior to jira ticket, if applicable.

Once all checks pass and the code is ready for review, please add `pmm-review-exporters` team as the reviewer. That would assign people from the review team automatically. Report any issues on our [Forum](https://forums.percona.com).
